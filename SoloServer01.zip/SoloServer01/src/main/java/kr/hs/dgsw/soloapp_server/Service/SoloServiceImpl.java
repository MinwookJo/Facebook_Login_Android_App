package kr.hs.dgsw.soloapp_server.Service;

import kr.hs.dgsw.soloapp_server.Controller.ResponseFormat;
import kr.hs.dgsw.soloapp_server.Model.MatchedUser;
import kr.hs.dgsw.soloapp_server.Model.SoloMapper;
import kr.hs.dgsw.soloapp_server.Model.SoloUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SoloServiceImpl implements SoloService{
    @Autowired
    SoloMapper soloMapper;
    private int seat = 0;

    @Override
    public ResponseFormat view(String id) {
        ResponseFormat rf = new ResponseFormat();
        MatchedUser mu = new MatchedUser();
        SoloUser soloUser1 = soloMapper.getUserById(id);
        SoloUser soloUser2 = null;
        int idx = 0;
        if(soloUser1!=null) {
            idx = soloUser1.getIdx();
        }else {
            rf.setDescription("Fail to get user");
            return rf;
        }
        if(idx%2==0){
            soloUser2 = soloMapper.getUserByIdx(idx-1);
        }
        else if (idx%2==1){
            soloUser2 = soloMapper.getUserByIdx(idx+1);
        }
        if(soloUser1==null){
            rf.setCode(101);
            rf.setDescription("Fail to get user");
            return rf;
        }
        if(soloUser2==null){
            rf.setCode(102);
            rf.setDescription("Fail to Match");
            return rf;
        }

        mu.setSoloUser1(soloUser1);
        mu.setSoloUser2(soloUser2);
        seat += 1;
        mu.setSeat(seat);
        rf.setMatchedUser(mu);
        return rf;
    }

    @Override
    public ResponseFormat insert(SoloUser user) {
        ResponseFormat rf = new ResponseFormat();
        String userId = user.getId();
        SoloUser soloUser = soloMapper.getUserById(user.getId());

        if(soloUser == null) {
            int num_affected = soloMapper.insert(user);
            if (num_affected == 0) {
                rf.setCode(103);
                rf.setDescription("insert fail");
            }
        }else {
            rf.setCode(106);
            rf.setDescription("already exist user");
        }

        return rf;

    }

    @Override
    public ResponseFormat delete(int idx) {
        ResponseFormat rf = new ResponseFormat();
        int num_affected = soloMapper.delete(idx);
        if(num_affected == 0) {
            rf.setCode(104);
            rf.setDescription("delete fail");
        }
        return rf;
    }

    @Override
    public ResponseFormat deleteAll() {
        ResponseFormat rf = new ResponseFormat();
        int num_affected = soloMapper.deleteAll();
        if(num_affected == 0) {
            rf.setCode(105);
            rf.setDescription("deleteAll fail");
        }
        return rf;
    }

    @Override
    public SoloUser getUserById(String id) {
        SoloUser soloUser = soloMapper.getUserById(id);
        if(soloUser==null){
            System.out.println("does not exist user by id");
        }
        return soloUser;
    }

    @Override
    public SoloUser getUserByIdx(int idx) {
        SoloUser soloUser = soloMapper.getUserByIdx(idx);
        if(soloUser==null){
            System.out.println("does not exist user by id");
        }
        return  soloUser;
    }
}
