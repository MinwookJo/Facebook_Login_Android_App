package kr.hs.dgsw.soloapp_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoloappServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoloappServerApplication.class, args);
	}
}
