package kr.hs.dgsw.soloapp_server.Model;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SoloMapper {
    public SoloUser view(@Param("id")String id);
    public int insert(SoloUser soloUser);
    public int delete(@Param("idx")int idx);
    public int deleteAll();
    public SoloUser getUserById(@Param("id")String id);
    public SoloUser getUserByIdx(@Param("idx")int idx);
}
