package kr.hs.dgsw.soloapp_server.Service;

import kr.hs.dgsw.soloapp_server.Controller.ResponseFormat;
import kr.hs.dgsw.soloapp_server.Model.SoloUser;

public interface SoloService {
    public ResponseFormat view(String id);
    public ResponseFormat insert(SoloUser user);
    public ResponseFormat delete(int idx);
    public ResponseFormat deleteAll();
    public SoloUser getUserById(String id);
    public SoloUser getUserByIdx(int idx);
}
