package kr.hs.dgsw.soloapp_server.Controller;

import kr.hs.dgsw.soloapp_server.Model.SoloUser;
import kr.hs.dgsw.soloapp_server.Service.SoloService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/solo")
public class SoloController {
    @Autowired
    SoloService soloService;

    @GetMapping("/{id}")
    public ResponseFormat view(@PathVariable("id")String id){
        return soloService.view(id);
    }

    @PostMapping
    public ResponseFormat insert(@RequestBody SoloUser soloUser){
        return soloService.insert(soloUser);
    }

    @DeleteMapping("/{idx}")
    public ResponseFormat delete(@PathVariable int idx){
        return soloService.delete(idx);
    }

    @GetMapping("/end")
    public ResponseFormat deleteAll(){
        return soloService.deleteAll();
    }
}
