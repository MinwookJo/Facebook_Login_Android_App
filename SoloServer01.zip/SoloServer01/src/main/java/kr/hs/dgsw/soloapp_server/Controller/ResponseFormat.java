package kr.hs.dgsw.soloapp_server.Controller;

import kr.hs.dgsw.soloapp_server.Model.MatchedUser;
import kr.hs.dgsw.soloapp_server.Model.SoloUser;

public class ResponseFormat {
    int code;
    String description;
    MatchedUser matchedUser;

    public void fail(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public ResponseFormat() {
        this.code = 0;
        this.description = "success";
        this.matchedUser = null;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public MatchedUser getMatchedUser() {
        return matchedUser;
    }

    public void setMatchedUser(MatchedUser matchedUser) {
        this.matchedUser = matchedUser;
    }
}
