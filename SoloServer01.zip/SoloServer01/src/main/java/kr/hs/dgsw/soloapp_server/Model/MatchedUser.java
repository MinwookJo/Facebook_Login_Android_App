package kr.hs.dgsw.soloapp_server.Model;


public class MatchedUser {
    SoloUser soloUser1;
    SoloUser soloUser2;
    int seat;

    public SoloUser getSoloUser1() {
        return soloUser1;
    }

    public void setSoloUser1(SoloUser soloUser1) {
        this.soloUser1 = soloUser1;
    }

    public SoloUser getSoloUser2() {
        return soloUser2;
    }

    public void setSoloUser2(SoloUser soloUser2) {
        this.soloUser2 = soloUser2;
    }

    public int getSeat() {
        return seat;
    }

    public void setSeat(int seat) {
        this.seat = seat;
    }
}
